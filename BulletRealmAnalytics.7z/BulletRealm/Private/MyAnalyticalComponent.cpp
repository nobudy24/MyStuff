// Fill out your copyright notice in the Description page of Project Settings.

#include "MyAnalyticalComponent.h"
#include "Engine.h"

// Sets default values for this component's properties
UMyAnalyticalComponent::UMyAnalyticalComponent()
{
	PlayerLoc = FVector(0, 0, 0);
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = true;
	Interval = 1.0f;
	// ...
}


// Called when the game starts
void UMyAnalyticalComponent::BeginPlay()
{
	Super::BeginPlay();
	GetWorld()->GetTimerManager().SetTimer(_loopTimerHandle, this, &UMyAnalyticalComponent::onTimerEnd,Interval,false);
	//...
	
}


// Called every frame
void UMyAnalyticalComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
	// ...
}

void UMyAnalyticalComponent::TrackData()
{
	ACharacter* myCharacterLocationPtr = UGameplayStatics::GetPlayerCharacter(GetWorld(), 0);
	
	//Deans way
	PlayerLoc.X = myCharacterLocationPtr->GetActorLocation().X;
	PlayerLoc.Y = myCharacterLocationPtr->GetActorLocation().Y;

	float IntXVal = PlayerLoc.X;
	float IntYVal = PlayerLoc.Y;

	int32 XVal = (int32)IntXVal;
	int32 YVal = (int32)IntYVal;

	FString ThePlayerLocVal = FString::Printf(TEXT("the value of playerLocation is ,X:%d,Y:%d"),XVal,YVal);
	GEngine->AddOnScreenDebugMessage(-1, 5.0, FColor::Yellow, *ThePlayerLocVal);
	
	//Interwebs way
	//GEngine->AddOnScreenDebugMessage(-1, 3.0, FColor::Red, *myCharacterLocationPtr->GetActorLocation().ToString());

	//set Timer again
	GetWorld()->GetTimerManager().SetTimer(_loopTimerHandle, this, &UMyAnalyticalComponent::onTimerEnd,Interval,false);
}

void UMyAnalyticalComponent::onTimerEnd()
{
	//Do many things here
	TrackData();

}
