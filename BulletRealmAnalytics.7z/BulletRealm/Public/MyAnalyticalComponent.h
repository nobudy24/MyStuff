// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "MyAnalyticalComponent.generated.h"


UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class BULLETREALM_API UMyAnalyticalComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	UMyAnalyticalComponent();
	//the location of the player 
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = Analytics)
	FVector PlayerLoc;
	//the Time it takes to Track Data
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Analytics)
	float Interval;

protected:
	// Called when the game starts
	virtual void BeginPlay() override;
	// will track the location of the character eact frame
	void TrackData();

public:	
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	//Create a timer handle to handle timing related functions
	void onTimerEnd();
	
private:
	//USphereComponent* _collision;
	
	FTimerHandle _loopTimerHandle;
	
};
